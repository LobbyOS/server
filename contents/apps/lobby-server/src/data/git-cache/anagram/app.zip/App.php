<?php
namespace Lobby\App;

/**
 * Have fun and don't forget to mess around the code
 * - Subin Siby - //subinsb.com
 */
class anagram extends \Lobby\App {
  
  public function page($p){
    return "auto";
  }
  
}
?>
