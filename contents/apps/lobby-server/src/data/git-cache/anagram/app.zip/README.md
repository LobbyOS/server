# Anagram

The classic Anagram Game for [Lobby](//lobby.subinsb.com).

Read how I created the Anagram game [here](//subinsb.com/lobby-anagram).
