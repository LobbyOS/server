<?php
echo $this->money();
