<div class="contents">
  <h1>Millionaire</h1>
  <p>Play the TV Show Game 'Who Wants To Be A Millionaire'</p>
  <a class='button green' style='width: 200px;font-size: 1.5rem;margin-top: 15px;' href='<?php echo $this->u("/single");?>'>Play</a>
  <h2>Understand Before You Play</h2>
  <ul>
    <li>No Actual/Real Money is awarded</li>
    <li>App currently consists of 30 questions. So, questions may<br/>be repeated after you play again.</li>
  </ul>
</div>
